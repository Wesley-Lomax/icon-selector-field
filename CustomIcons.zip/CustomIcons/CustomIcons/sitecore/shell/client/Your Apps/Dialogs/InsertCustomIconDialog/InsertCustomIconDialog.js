﻿define(["sitecore", "jquery"], function (Sitecore, jQuery) {
    var CustomIconListPage = Sitecore.Definitions.App.extend({
        initialized: function () {
           
        },
       
    });
    return CustomIconListPage;
});